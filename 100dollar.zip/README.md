# 100dollar
100dollar is an ongoing project in the CSE326 at Hanyang University
## Team member
* [김덕영](https://github.com/dudejrs) - course
* [김동규](https://github.com/kimdg1105) - members
* [박재용](https://github.com/ggjae) - about
* [오승기](https://github.com/OhSeung-Ki) - publication
* [이세명](https://github.com/3people) - main
